# Public Assets

The public assets are stored in the `public/` directory in the root of the project.

It can contains the following assets:

- PWA assets (icons, manifest, service worker, etc...)
- File Uploaded in `public/uploads`
- Static Assets (img, etc)
- Fonts (`public/built`)
