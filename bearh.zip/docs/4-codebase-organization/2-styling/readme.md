# Styling

The app use Tailwind CSS 3 for styling.

The main configuration file is [tailwind.config.js](../../tailwind.config.js)

The main stylesheet is [tailwind.css](../../app/tailwind.css)

Learn more at [3-design-system/readme.md](../../3-design-system/readme.md)


