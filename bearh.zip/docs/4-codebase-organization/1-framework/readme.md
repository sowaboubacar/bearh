# Framework
The app is built with RemixJS.

Learn more about RemixJS: https://remix.run/

We have previously talked about the core libraries and the application configuration in the [Introduction](../../1-introduction/readme.md) file.
