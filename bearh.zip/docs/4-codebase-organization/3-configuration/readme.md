# Configuration

The [2-application-functionality/readme.md](../../2-application-functionality/readme.md) tells you how to configure the application.

Notice that you can also add client side configuration in the `app/config/config.client.ts` file.
