export const convertMeterToKilometer = (meters: number) => meters / 1000;
